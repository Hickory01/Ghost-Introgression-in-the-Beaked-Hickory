thread=1
for((i=1;i<=8;i++))
do
	sed -i s/b1/b$i/g A00.ctl.$i
	echo "sed -i 's/2 169 1/20 $thread 1/g' A00.ctl.$i"
	((thread=$thread+24))
#	`bpp --cfile A00.ctl.$i >log.b$i.txt`;
done

