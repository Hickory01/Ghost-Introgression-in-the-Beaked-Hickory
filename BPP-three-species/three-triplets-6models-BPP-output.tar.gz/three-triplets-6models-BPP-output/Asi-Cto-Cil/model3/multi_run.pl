use strict;
use warnings;
for(my $i=1;$i<=8;$i++){
	`sed -i s/b1/b$i/g A00.ctl.$i`;
	`nohup bpp --cfile A00.ctl.$i >log.b$i.txt &`;
}
