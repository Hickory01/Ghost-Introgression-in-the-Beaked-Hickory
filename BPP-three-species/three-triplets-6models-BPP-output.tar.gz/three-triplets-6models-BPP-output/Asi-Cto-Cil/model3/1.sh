sed -i 's/2 169 1/20 1 1/g' A00.ctl.1
sed -i 's/2 169 1/20 25 1/g' A00.ctl.2
sed -i 's/2 169 1/20 49 1/g' A00.ctl.3
sed -i 's/2 169 1/20 73 1/g' A00.ctl.4
sed -i 's/2 169 1/20 97 1/g' A00.ctl.5
sed -i 's/2 169 1/20 121 1/g' A00.ctl.6
sed -i 's/2 169 1/20 145 1/g' A00.ctl.7
sed -i 's/2 169 1/20 169 1/g' A00.ctl.8
