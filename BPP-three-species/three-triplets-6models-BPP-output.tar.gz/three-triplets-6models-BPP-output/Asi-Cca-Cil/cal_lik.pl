use strict;
use warnings;
sub help{
	print "perl xxx.pl dir/ \n";
}
if($ARGV[0] eq "-h"){
	&help;
}else{
	my @model = (1,2,3,4,5,6);
	foreach my $i(@model){
		open(IN,"$ARGV[0]/model$i/betaweights.csv") or die;
		my $n = 0;
		my %weight;
		while(<IN>){
			chomp;
			next if (/^beta/);
			my @it = split(/\,/,$_);
			$n++;
			$weight{$n} = $it[1];
		}
		close(IN);
		my $log = 0;
		foreach my $j(1 .. 8){
			if(-e "$ARGV[0]/model$i/log.b$j.txt"){
				open(IN,"$ARGV[0]/model$i/log.b$j.txt") or die;
				while(<IN>){
					chomp;
					if(/BFbeta/){
						my @tmp = split(/\s=\s/,$_);
						#print "model$i\t$tmp[-1]\n";
						$log += ($tmp[-1]*$weight{$j})/2;	
					}
				}
				close(IN);
			}
		}
		print "model$i\t$log\n";
	}
}
